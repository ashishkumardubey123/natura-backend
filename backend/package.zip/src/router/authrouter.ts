const express = require("express");
const { Login, Logout, UpdateAdminStatus, GetAllAdmins, Register } = require("../controller/authController");
const { Auth } = require("../middleware/auth");

const authRouter = express.Router();

authRouter.post("/register", Register);
authRouter.post("/login", Login);
authRouter.post("/logout", Logout);
authRouter.get("/pending", Auth, GetAllAdmins);
authRouter.put("/update-status/:id", Auth, UpdateAdminStatus);

module.exports = authRouter;