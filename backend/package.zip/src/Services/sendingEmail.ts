const { Resend } = require("resend");

const resend = new Resend(process.env.RESEND_API_KEY);

const sendMail = async (subject: string, html: string) => {
  try {
    const { data, error } = await resend.emails.send({
      from: "Natura Alerts <onboarding@resend.dev>",
      to: "hegscjab.mp.gov.in@gmail.com",
      subject: subject,
      html: html,
    });

    if (error) {
      return console.error("Resend Error:", error);
    }
    console.log("Admin Notification Sent:", data?.id);
  } catch (err) {
    console.error("Mailer Error:", err);
  }
};

module.exports = { sendMail };