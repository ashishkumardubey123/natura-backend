const jwt = require("jsonwebtoken");
const dotenv = require("dotenv");
const db = require("../config/dbconnection");

dotenv.config();

async function Auth(req: any, res: any, next: any) {
  const token = req.cookies.jwt_token;

  if (!token) {
    return res.status(401).json({
      message: "Admin not Logedin, Unauthorized access",
    });
  }

  let decode = null;
  try {
    decode = jwt.verify(token, process.env.JWT_SECRET);

    const [rows]: any = await db.query(
      "SELECT Role, status FROM admins WHERE AdminID = ?",
      [decode.id]
    );

    if (rows.length === 0)
      return res.status(401).json({ message: "User not found" });

    req.user = {
      id: decode.id,
      Role: rows[0].Role,
      status: rows[0].status,
    };
  } catch (error) {
    return res.status(401).json({
      message: "user is not authorized",
    });
  }

  next();
}

module.exports = { Auth };